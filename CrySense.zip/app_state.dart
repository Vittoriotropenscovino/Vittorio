import 'package:flutter/material.dart';
import '../models/baby_profile.dart';
import '../models/cry_record.dart';
import '../models/cry_type.dart';
import '../services/database_service.dart';
import '../services/audio_service.dart';
import '../services/ml_service.dart';

class AppState extends ChangeNotifier {
  final DatabaseService _db = DatabaseService.instance;
  final AudioService _audio = AudioService();
  final MLService _ml = MLService.instance;

  BabyProfile? _currentBaby;
  List<CryRecord> _recentRecords = [];
  Map<CryType, int> _todayStats = {};
  bool _isLoading = false;
  bool _isAnalyzing = false;

  BabyProfile? get currentBaby => _currentBaby;
  List<CryRecord> get recentRecords => _recentRecords;
  Map<CryType, int> get todayStats => _todayStats;
  bool get isLoading => _isLoading;
  bool get isAnalyzing => _isAnalyzing;
  AudioService get audioService => _audio;

  Future<void> initialize() async {
    _isLoading = true;
    notifyListeners();

    try {
      await _ml.loadModel();
      final profiles = await _db.getAllBabyProfiles();
      if (profiles.isNotEmpty) {
        _currentBaby = profiles.first;
        await loadRecentRecords();
        await loadTodayStats();
      }
    } catch (e) {
      print('Error initializing: $e');
    }

    _isLoading = false;
    notifyListeners();
  }

  Future<void> createBaby(String name, DateTime birthDate) async {
    final baby = BabyProfile(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      name: name,
      birthDate: birthDate,
      createdAt: DateTime.now(),
    );

    await _db.createBabyProfile(baby);
    _currentBaby = baby;
    notifyListeners();
  }

  Future<CryRecord?> analyzeCry(String audioPath) async {
    if (_currentBaby == null) return null;

    _isAnalyzing = true;
    notifyListeners();

    try {
      final probabilities = await _ml.analyzeWithPersonalization(
        audioPath,
        _currentBaby!.id,
      );

      final predictedType = _ml.getPredictedType(probabilities);
      final confidence = _ml.getConfidence(probabilities, predictedType);

      final record = CryRecord(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        babyId: _currentBaby!.id,
        timestamp: DateTime.now(),
        predictedType: predictedType,
        confidence: confidence,
        audioPath: audioPath,
        allProbabilities: probabilities,
      );

      await _db.createCryRecord(record);
      await loadRecentRecords();
      await loadTodayStats();

      _isAnalyzing = false;
      notifyListeners();

      return record;
    } catch (e) {
      print('Error analyzing cry: $e');
      _isAnalyzing = false;
      notifyListeners();
      return null;
    }
  }

  Future<void> confirmCryType(CryRecord record, CryType actualType) async {
    final updated = record.copyWith(confirmedType: actualType);
    await _db.updateCryRecord(updated);

    // Feedback per migliorare il modello
    if (record.audioPath != null) {
      await _ml.updateModelWithFeedback(
        audioPath: record.audioPath!,
        predictedType: record.predictedType,
        actualType: actualType,
      );
    }

    await loadRecentRecords();
    await loadTodayStats();
    notifyListeners();
  }

  Future<void> loadRecentRecords() async {
    if (_currentBaby == null) return;

    _recentRecords = await _db.getCryRecords(
      _currentBaby!.id,
      limit: 20,
    );
    notifyListeners();
  }

  Future<void> loadTodayStats() async {
    if (_currentBaby == null) return;

    final today = DateTime.now();
    final startOfDay = DateTime(today.year, today.month, today.day);
    final endOfDay = startOfDay.add(const Duration(days: 1));

    _todayStats = await _db.getCryStatistics(
      _currentBaby!.id,
      startDate: startOfDay,
      endDate: endOfDay,
    );
    notifyListeners();
  }

  Future<Map<CryType, int>> getStatsForPeriod({
    required DateTime startDate,
    required DateTime endDate,
  }) async {
    if (_currentBaby == null) return {};

    return await _db.getCryStatistics(
      _currentBaby!.id,
      startDate: startDate,
      endDate: endDate,
    );
  }

  CryRecord? getLastRecordOfType(CryType type) {
    try {
      return _recentRecords.firstWhere(
        (record) => record.actualType == type,
      );
    } catch (e) {
      return null;
    }
  }

  String getTimeSinceLastCry(CryType type) {
    final lastRecord = getLastRecordOfType(type);
    if (lastRecord == null) return 'Mai';

    final difference = DateTime.now().difference(lastRecord.timestamp);
    if (difference.inMinutes < 60) {
      return '${difference.inMinutes}min fa';
    } else if (difference.inHours < 24) {
      return '${difference.inHours}h fa';
    } else {
      return '${difference.inDays}g fa';
    }
  }

  @override
  void dispose() {
    _audio.dispose();
    super.dispose();
  }
}
