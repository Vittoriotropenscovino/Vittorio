import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';
import 'result_screen.dart';

class ListeningScreen extends StatefulWidget {
  const ListeningScreen({super.key});

  @override
  State<ListeningScreen> createState() => _ListeningScreenState();
}

class _ListeningScreenState extends State<ListeningScreen> {
  bool _isRecording = false;
  int _secondsElapsed = 0;
  Timer? _timer;
  StreamSubscription? _amplitudeSubscription;
  List<double> _amplitudes = List.filled(20, 0.0);

  @override
  void initState() {
    super.initState();
    _startRecording();
  }

  Future<void> _startRecording() async {
    final appState = Provider.of<AppState>(context, listen: false);
    final audioPath = await appState.audioService.startRecording(maxDuration: 7);

    if (audioPath != null) {
      setState(() => _isRecording = true);

      // Timer per il contatore
      _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
        if (mounted) {
          setState(() => _secondsElapsed++);
        }
      });

      // Ascolta le ampiezze per l'animazione
      _amplitudeSubscription =
          appState.audioService.amplitudeStream.listen((amplitude) {
        if (mounted) {
          setState(() {
            _amplitudes.removeAt(0);
            _amplitudes.add(amplitude.clamp(-80.0, 0.0).abs() / 80.0);
          });
        }
      });

      // Auto-stop dopo 7 secondi
      Future.delayed(const Duration(seconds: 7), () {
        if (mounted && _isRecording) {
          _stopAndAnalyze();
        }
      });
    } else {
      // Permesso negato
      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Permesso microfono necessario'),
          ),
        );
      }
    }
  }

  Future<void> _stopAndAnalyze() async {
    _timer?.cancel();
    _amplitudeSubscription?.cancel();

    final appState = Provider.of<AppState>(context, listen: false);
    final audioPath = await appState.audioService.stopRecording();

    if (audioPath != null && mounted) {
      setState(() => _isRecording = false);

      // Vai alla schermata di analisi
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => ResultScreen(audioPath: audioPath),
        ),
      );
    }
  }

  Future<void> _cancel() async {
    _timer?.cancel();
    _amplitudeSubscription?.cancel();

    final appState = Provider.of<AppState>(context, listen: false);
    await appState.audioService.cancelRecording();

    if (mounted) {
      Navigator.pop(context);
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    _amplitudeSubscription?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[50],
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.close),
          onPressed: _cancel,
        ),
      ),
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                '🎙️ Ascolto in corso...',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 40),

              // Waveform animation
              SizedBox(
                height: 120,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: _amplitudes.asMap().entries.map((entry) {
                    return AnimatedContainer(
                      duration: const Duration(milliseconds: 100),
                      width: 4,
                      height: 20 + (entry.value * 100),
                      margin: const EdgeInsets.symmetric(horizontal: 2),
                      decoration: BoxDecoration(
                        color: Colors.blue[600],
                        borderRadius: BorderRadius.circular(2),
                      ),
                    );
                  }).toList(),
                ),
              ),

              const SizedBox(height: 40),

              // Timer
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 24,
                  vertical: 12,
                ),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Text(
                  '⏱️ 00:0$_secondsElapsed',
                  style: const TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'monospace',
                  ),
                ),
              ),

              const SizedBox(height: 60),

              // Stop button
              ElevatedButton(
                onPressed: _stopAndAnalyze,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red[400],
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 48,
                    vertical: 16,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                  elevation: 5,
                ),
                child: const Text(
                  'FERMA',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1,
                  ),
                ),
              ),

              const SizedBox(height: 20),

              Text(
                'Registrazione automatica fino a 7 secondi',
                style: TextStyle(
                  fontSize: 12,
                  color: Colors.grey[600],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
