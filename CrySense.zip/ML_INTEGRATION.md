# 🧠 Guida Integrazione Modello ML Reale

Questa guida spiega come sostituire il classificatore simulato con un modello TensorFlow Lite reale.

## 📋 Panoramica del Processo

```
Dataset → Training → TFLite → Integrazione App → Testing
```

## 1️⃣ Preparazione Dataset

### Struttura Raccomandata

```
dataset/
├── train/
│   ├── hunger/
│   │   ├── cry_001.wav
│   │   ├── cry_002.wav
│   │   └── ...
│   ├── sleepy/
│   ├── pain/
│   ├── diaper/
│   ├── gas/
│   └── attention/
├── validation/
│   └── [stessa struttura]
└── test/
    └── [stessa struttura]
```

### Fonti Dataset

1. **Baby Chillanto Database**
   - URL: http://www.nal-lab.com/baby-cry-database
   - Formato: WAV
   - Dimensione: ~1000 file

2. **Kaggle**
   - Cerca: "baby cry classification"
   - Diverse opzioni disponibili

3. **Crowdsourcing** (futuro)
   - Raccogli dati dagli utenti (con consenso)
   - Etichettatura da parte dei genitori + validazione esperta

## 2️⃣ Script di Training Python

Salva questo come `training/train_model.py`:

```python
import tensorflow as tf
import numpy as np
import librosa
import os
from sklearn.model_selection import train_test_split
from tensorflow import keras

# Configurazione
SAMPLE_RATE = 16000
DURATION = 7
N_MFCC = 13
N_MELS = 128
CLASSES = ['hunger', 'sleepy', 'pain', 'diaper', 'gas', 'attention']

def extract_features(file_path):
    """Estrae MFCC e Mel-spectrogram dall'audio"""
    # Carica audio
    audio, sr = librosa.load(file_path, sr=SAMPLE_RATE, duration=DURATION)
    
    # Padding se necessario
    if len(audio) < SAMPLE_RATE * DURATION:
        audio = np.pad(audio, (0, SAMPLE_RATE * DURATION - len(audio)))
    
    # MFCC
    mfccs = librosa.feature.mfcc(y=audio, sr=sr, n_mfcc=N_MFCC)
    
    # Mel-spectrogram
    mel_spec = librosa.feature.melspectrogram(
        y=audio, 
        sr=sr, 
        n_mels=N_MELS
    )
    mel_spec_db = librosa.power_to_db(mel_spec, ref=np.max)
    
    return mel_spec_db

def load_dataset(data_dir):
    """Carica il dataset e estrae le features"""
    X = []
    y = []
    
    for idx, class_name in enumerate(CLASSES):
        class_dir = os.path.join(data_dir, class_name)
        
        for file_name in os.listdir(class_dir):
            if file_name.endswith('.wav'):
                file_path = os.path.join(class_dir, file_name)
                
                try:
                    features = extract_features(file_path)
                    X.append(features)
                    y.append(idx)
                except Exception as e:
                    print(f"Errore con {file_path}: {e}")
    
    return np.array(X), np.array(y)

def create_model(input_shape, num_classes):
    """Crea il modello CNN-LSTM"""
    model = keras.Sequential([
        # Input layer
        keras.layers.Input(shape=input_shape),
        
        # Conv blocks
        keras.layers.Conv2D(32, (3, 3), activation='relu', padding='same'),
        keras.layers.BatchNormalization(),
        keras.layers.MaxPooling2D((2, 2)),
        keras.layers.Dropout(0.25),
        
        keras.layers.Conv2D(64, (3, 3), activation='relu', padding='same'),
        keras.layers.BatchNormalization(),
        keras.layers.MaxPooling2D((2, 2)),
        keras.layers.Dropout(0.25),
        
        keras.layers.Conv2D(128, (3, 3), activation='relu', padding='same'),
        keras.layers.BatchNormalization(),
        keras.layers.MaxPooling2D((2, 2)),
        keras.layers.Dropout(0.25),
        
        # Reshape per LSTM
        keras.layers.Reshape((-1, 128)),
        
        # LSTM per pattern temporali
        keras.layers.LSTM(64, return_sequences=False),
        keras.layers.Dropout(0.5),
        
        # Dense layers
        keras.layers.Dense(128, activation='relu'),
        keras.layers.Dropout(0.5),
        keras.layers.Dense(num_classes, activation='softmax')
    ])
    
    return model

def train_model():
    """Pipeline completo di training"""
    print("📁 Caricamento dataset...")
    X, y = load_dataset('dataset/train')
    
    # Reshape per CNN (aggiungi canale)
    X = X[..., np.newaxis]
    
    # One-hot encoding
    y = keras.utils.to_categorical(y, num_classes=len(CLASSES))
    
    # Split
    X_train, X_val, y_train, y_val = train_test_split(
        X, y, test_size=0.15, random_state=42
    )
    
    print(f"✅ Dataset caricato: {X_train.shape[0]} train, {X_val.shape[0]} val")
    
    # Crea modello
    print("🏗️ Creazione modello...")
    model = create_model(
        input_shape=X_train.shape[1:],
        num_classes=len(CLASSES)
    )
    
    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=0.001),
        loss='categorical_crossentropy',
        metrics=['accuracy']
    )
    
    model.summary()
    
    # Callbacks
    callbacks = [
        keras.callbacks.EarlyStopping(
            monitor='val_loss',
            patience=10,
            restore_best_weights=True
        ),
        keras.callbacks.ReduceLROnPlateau(
            monitor='val_loss',
            factor=0.5,
            patience=5
        ),
        keras.callbacks.ModelCheckpoint(
            'models/best_model.h5',
            monitor='val_accuracy',
            save_best_only=True
        )
    ]
    
    # Training
    print("🚀 Inizio training...")
    history = model.fit(
        X_train, y_train,
        validation_data=(X_val, y_val),
        epochs=100,
        batch_size=32,
        callbacks=callbacks,
        verbose=1
    )
    
    # Valutazione
    print("\n📊 Valutazione modello...")
    val_loss, val_acc = model.evaluate(X_val, y_val)
    print(f"Validation Accuracy: {val_acc:.2%}")
    
    return model, history

def convert_to_tflite(model, output_path='models/cry_classifier.tflite'):
    """Converte il modello in TensorFlow Lite"""
    print("🔄 Conversione a TensorFlow Lite...")
    
    # Converter con ottimizzazioni
    converter = tf.lite.TFLiteConverter.from_keras_model(model)
    
    # Ottimizzazioni per mobile
    converter.optimizations = [tf.lite.Optimize.DEFAULT]
    
    # Quantizzazione (opzionale, riduce dimensione)
    # converter.target_spec.supported_types = [tf.float16]
    
    # Converti
    tflite_model = converter.convert()
    
    # Salva
    with open(output_path, 'wb') as f:
        f.write(tflite_model)
    
    size_mb = len(tflite_model) / (1024 * 1024)
    print(f"✅ Modello salvato: {output_path} ({size_mb:.2f} MB)")

if __name__ == '__main__':
    # Training
    model, history = train_model()
    
    # Conversione a TFLite
    convert_to_tflite(model)
    
    print("\n🎉 Training completato!")
    print("📝 Prossimi passi:")
    print("1. Copia 'models/cry_classifier.tflite' in 'baby_cry_app/assets/models/'")
    print("2. Aggiorna pubspec.yaml per includere gli assets")
    print("3. Implementa l'analisi reale in ml_service.dart")
```

## 3️⃣ Installazione Dipendenze Python

```bash
pip install tensorflow librosa numpy scikit-learn
```

## 4️⃣ Esecuzione Training

```bash
cd training
python train_model.py
```

## 5️⃣ Integrazione nell'App

### A. Aggiungi il modello agli assets

1. Copia il file `.tflite` generato:
```bash
cp training/models/cry_classifier.tflite baby_cry_app/assets/models/
```

2. Aggiorna `pubspec.yaml`:
```yaml
flutter:
  assets:
    - assets/models/cry_classifier.tflite
```

### B. Aggiungi dipendenza TFLite

In `pubspec.yaml`:
```yaml
dependencies:
  tflite_flutter: ^0.10.4
```

### C. Implementa in ml_service.dart

Sostituisci il contenuto di `lib/services/ml_service.dart`:

```dart
import 'dart:typed_data';
import 'package:tflite_flutter/tflite_flutter.dart';
import '../models/cry_type.dart';

class MLService {
  static final MLService instance = MLService._init();
  Interpreter? _interpreter;
  
  MLService._init();

  Future<void> loadModel() async {
    try {
      _interpreter = await Interpreter.fromAsset(
        'assets/models/cry_classifier.tflite'
      );
      print('✅ Modello ML caricato');
    } catch (e) {
      print('❌ Errore caricamento modello: $e');
    }
  }

  Future<Map<CryType, double>> analyzeCry(String audioPath) async {
    if (_interpreter == null) {
      throw Exception('Modello non caricato');
    }

    // 1. Estrai features dall'audio
    final features = await _extractFeatures(audioPath);
    
    // 2. Preprocessing
    final input = _preprocessFeatures(features);
    
    // 3. Inferenza
    final output = List.filled(6, 0.0).reshape([1, 6]);
    _interpreter!.run(input, output);
    
    // 4. Converti output in probabilità per tipo
    return _outputToProbabilities(output[0]);
  }

  Future<Float32List> _extractFeatures(String audioPath) async {
    // Qui implementa l'estrazione MFCC/Mel-spectrogram
    // Puoi usare FFI per chiamare librerie native
    // oppure un package Flutter per audio processing
    
    // Per ora, placeholder
    return Float32List(128 * 128);
  }

  Float32List _preprocessFeatures(Float32List features) {
    // Normalizzazione e reshape
    return features;
  }

  Map<CryType, double> _outputToProbabilities(List<double> output) {
    final types = [
      CryType.hunger,
      CryType.sleepy,
      CryType.pain,
      CryType.diaper,
      CryType.gas,
      CryType.attention,
    ];
    
    return Map.fromIterables(types, output);
  }

  CryType getPredictedType(Map<CryType, double> probabilities) {
    return probabilities.entries
        .reduce((a, b) => a.value > b.value ? a : b)
        .key;
  }

  double getConfidence(Map<CryType, double> probabilities, CryType type) {
    return probabilities[type] ?? 0.0;
  }
}
```

## 6️⃣ Testing

### Test del modello

```bash
# Testa su audio di validazione
python training/test_model.py
```

### Test nell'app

1. Build e installa:
```bash
flutter run --release
```

2. Testa con audio reali
3. Verifica accuratezza e latenza

## 📈 Ottimizzazione

### Migliorare l'Accuratezza

1. **Più dati**: Raccogli 5000+ campioni per classe
2. **Data Augmentation**: Pitch shift, time stretch, noise
3. **Transfer Learning**: Parti da modelli pre-trained (YAMNet, VGGish)
4. **Ensemble**: Combina più modelli

### Ridurre la Dimensione

1. **Quantizzazione**: Float32 → Float16 o Int8
2. **Pruning**: Rimuovi pesi poco importanti
3. **Knowledge Distillation**: Modello piccolo che imita uno grande

### Velocizzare l'Inferenza

1. **GPU Delegate**: Usa GPU su device supportati
2. **NNAPI** (Android): Accelerazione hardware
3. **Core ML** (iOS): Framework nativo Apple

## 🔍 Debugging

### Problemi Comuni

**Errore "Interpreter not loaded"**
```dart
// Verifica che loadModel() sia chiamato prima di usare il modello
await MLService.instance.loadModel();
```

**Dimensioni input non corrette**
```python
# Verifica che le dimensioni dell'input corrispondano
print(model.input_shape)  # Deve matchare le features estratte
```

**Accuratezza bassa**
- Aumenta il dataset
- Verifica che le classi siano bilanciate
- Controlla il preprocessing audio
- Aumenta la complessità del modello (con cautela)

## 📚 Risorse Utili

- [TensorFlow Lite Guide](https://www.tensorflow.org/lite/guide)
- [Librosa Documentation](https://librosa.org/doc/latest/)
- [Audio Classification Tutorial](https://www.tensorflow.org/tutorials/audio/simple_audio)
- [Flutter TFLite Package](https://pub.dev/packages/tflite_flutter)

## 🎯 Obiettivi di Performance

Target per produzione:
- **Accuratezza**: >85% su dataset test
- **Latenza**: <500ms per predizione
- **Dimensione modello**: <10MB
- **RAM**: <100MB durante inferenza

---

Buon training! 🚀
