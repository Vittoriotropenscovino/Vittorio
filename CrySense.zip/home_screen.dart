import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';
import '../models/cry_type.dart';
import 'listening_screen.dart';
import 'statistics_screen.dart';
import 'setup_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<AppState>(
      builder: (context, appState, child) {
        if (appState.currentBaby == null) {
          return const SetupScreen();
        }

        return Scaffold(
          backgroundColor: Colors.grey[50],
          appBar: AppBar(
            title: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '👶 ${appState.currentBaby!.name}',
                  style: const TextStyle(fontSize: 20),
                ),
                Text(
                  '${appState.currentBaby!.ageInMonths} mesi',
                  style: const TextStyle(fontSize: 12, fontWeight: FontWeight.normal),
                ),
              ],
            ),
            actions: [
              IconButton(
                icon: const Icon(Icons.bar_chart),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const StatisticsScreen(),
                    ),
                  );
                },
              ),
            ],
          ),
          body: SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  // Bottone principale di ascolto
                  _buildListenButton(context, appState),
                  const SizedBox(height: 30),

                  // Ultimo pianto
                  if (appState.recentRecords.isNotEmpty)
                    _buildLastCryCard(appState),

                  const SizedBox(height: 20),

                  // Statistiche di oggi
                  _buildTodayStatsCard(appState),

                  const SizedBox(height: 20),

                  // Lista recenti
                  _buildRecentList(appState),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildListenButton(BuildContext context, AppState appState) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => const ListeningScreen(),
          ),
        );
      },
      child: Container(
        height: 200,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.blue[400]!, Colors.blue[600]!],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.blue.withOpacity(0.3),
              blurRadius: 20,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        child: const Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.mic,
                size: 64,
                color: Colors.white,
              ),
              SizedBox(height: 16),
              Text(
                'ASCOLTA',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2,
                ),
              ),
              SizedBox(height: 8),
              Text(
                'Tocca per iniziare',
                style: TextStyle(
                  color: Colors.white70,
                  fontSize: 16,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLastCryCard(AppState appState) {
    final lastCry = appState.recentRecords.first;
    final timeDiff = DateTime.now().difference(lastCry.timestamp);
    String timeAgo;
    
    if (timeDiff.inMinutes < 60) {
      timeAgo = '${timeDiff.inMinutes} min fa';
    } else if (timeDiff.inHours < 24) {
      timeAgo = '${timeDiff.inHours}h fa';
    } else {
      timeAgo = '${timeDiff.inDays}g fa';
    }

    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Ultimo pianto',
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Text(
                  lastCry.actualType.emoji,
                  style: const TextStyle(fontSize: 32),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        lastCry.actualType.displayName,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        timeAgo,
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTodayStatsCard(AppState appState) {
    final stats = appState.todayStats;
    final sortedStats = stats.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    final topStats = sortedStats.take(3).where((e) => e.value > 0).toList();

    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Oggi',
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 16),
            if (topStats.isEmpty)
              const Center(
                child: Padding(
                  padding: EdgeInsets.symmetric(vertical: 20),
                  child: Text(
                    'Nessun pianto registrato oggi',
                    style: TextStyle(color: Colors.grey),
                  ),
                ),
              )
            else
              ...topStats.map((entry) => Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: Row(
                      children: [
                        Text(
                          entry.key.emoji,
                          style: const TextStyle(fontSize: 24),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            entry.key.displayName,
                            style: const TextStyle(fontSize: 16),
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            color: entry.key.color.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            '${entry.value}x',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: entry.key.color,
                            ),
                          ),
                        ),
                      ],
                    ),
                  )),
          ],
        ),
      ),
    );
  }

  Widget _buildRecentList(AppState appState) {
    if (appState.recentRecords.isEmpty) {
      return const SizedBox.shrink();
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.only(left: 4, bottom: 12),
          child: Text(
            'Storico Recente',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        ...appState.recentRecords.take(5).map((record) {
          final timeDiff = DateTime.now().difference(record.timestamp);
          String timeAgo;
          
          if (timeDiff.inMinutes < 60) {
            timeAgo = '${timeDiff.inMinutes}min';
          } else if (timeDiff.inHours < 24) {
            timeAgo = '${timeDiff.inHours}h';
          } else {
            timeAgo = '${timeDiff.inDays}g';
          }

          return Card(
            margin: const EdgeInsets.only(bottom: 8),
            child: ListTile(
              leading: Text(
                record.actualType.emoji,
                style: const TextStyle(fontSize: 28),
              ),
              title: Text(record.actualType.displayName),
              subtitle: Text(
                '${(record.confidence * 100).toInt()}% confidenza',
              ),
              trailing: Text(
                timeAgo,
                style: TextStyle(
                  color: Colors.grey[600],
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          );
        }),
      ],
    );
  }
}
