import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';
import '../models/cry_record.dart';
import '../models/cry_type.dart';

class ResultScreen extends StatefulWidget {
  final String audioPath;

  const ResultScreen({super.key, required this.audioPath});

  @override
  State<ResultScreen> createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen> {
  CryRecord? _result;
  bool _isAnalyzing = true;

  @override
  void initState() {
    super.initState();
    _analyzeAudio();
  }

  Future<void> _analyzeAudio() async {
    final appState = Provider.of<AppState>(context, listen: false);
    final result = await appState.analyzeCry(widget.audioPath);

    if (mounted) {
      setState(() {
        _result = result;
        _isAnalyzing = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isAnalyzing) {
      return Scaffold(
        backgroundColor: Colors.blue[50],
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(Colors.blue[600]!),
                strokeWidth: 6,
              ),
              const SizedBox(height: 24),
              const Text(
                '🧠 Analisi in corso...',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                'Sto ascoltando il pianto',
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey[600],
                ),
              ),
            ],
          ),
        ),
      );
    }

    if (_result == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Errore')),
        body: const Center(
          child: Text('Impossibile analizzare l\'audio'),
        ),
      );
    }

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.close),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Risultato'),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Success icon
              const Icon(
                Icons.check_circle,
                color: Colors.green,
                size: 64,
              ),
              const SizedBox(height: 16),

              const Center(
                child: Text(
                  '✅ Analisi completata',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),

              const SizedBox(height: 40),

              // Main result
              Container(
                padding: const EdgeInsets.all(32),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      _result!.predictedType.color.withOpacity(0.2),
                      _result!.predictedType.color.withOpacity(0.1),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: _result!.predictedType.color.withOpacity(0.3),
                    width: 2,
                  ),
                ),
                child: Column(
                  children: [
                    Text(
                      _result!.predictedType.emoji,
                      style: const TextStyle(fontSize: 64),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      _result!.predictedType.displayName.toUpperCase(),
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                        color: _result!.predictedType.color,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'Confidenza: ${(_result!.confidence * 100).toInt()}%',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.grey[700],
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 32),

              // Suggestions
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.blue[50],
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Row(
                      children: [
                        Icon(Icons.lightbulb, color: Colors.orange),
                        SizedBox(width: 8),
                        Text(
                          'Suggerimenti',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    ..._result!.predictedType.suggestions.map((suggestion) =>
                        Padding(
                          padding: const EdgeInsets.only(bottom: 12),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('• ', style: TextStyle(fontSize: 16)),
                              Expanded(
                                child: Text(
                                  suggestion,
                                  style: const TextStyle(fontSize: 15),
                                ),
                              ),
                            ],
                          ),
                        )),
                  ],
                ),
              ),

              const SizedBox(height: 32),

              // Feedback section
              const Text(
                'Era corretto?',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),

              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: () async {
                        await _confirmCorrect();
                        if (mounted) Navigator.pop(context);
                      },
                      icon: const Icon(Icons.check),
                      label: const Text('Sì, corretto'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () => _showCorrectionDialog(),
                      icon: const Icon(Icons.edit),
                      label: const Text('No, era...'),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.orange,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 16),

              // Back button
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Torna alla home'),
              ),

              const SizedBox(height: 32),

              // Probabilities (collapsible)
              _buildProbabilitiesSection(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildProbabilitiesSection() {
    final sortedProbs = _result!.allProbabilities.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    return ExpansionTile(
      title: const Text(
        'Dettagli tecnici',
        style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
      ),
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: sortedProbs.map((entry) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Text(entry.key.emoji),
                        const SizedBox(width: 8),
                        Expanded(child: Text(entry.key.displayName)),
                        Text(
                          '${(entry.value * 100).toInt()}%',
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    LinearProgressIndicator(
                      value: entry.value,
                      backgroundColor: Colors.grey[200],
                      valueColor: AlwaysStoppedAnimation(entry.key.color),
                    ),
                  ],
                ),
              );
            }).toList(),
          ),
        ),
      ],
    );
  }

  Future<void> _confirmCorrect() async {
    final appState = Provider.of<AppState>(context, listen: false);
    await appState.confirmCryType(_result!, _result!.predictedType);
  }

  void _showCorrectionDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Qual era il vero motivo?'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: CryType.values
              .where((type) => type != CryType.unknown)
              .map((type) => ListTile(
                    leading: Text(type.emoji, style: const TextStyle(fontSize: 24)),
                    title: Text(type.displayName),
                    onTap: () async {
                      Navigator.pop(context);
                      await _confirmCorrection(type);
                      if (mounted) Navigator.pop(context);
                    },
                  ))
              .toList(),
        ),
      ),
    );
  }

  Future<void> _confirmCorrection(CryType actualType) async {
    final appState = Provider.of<AppState>(context, listen: false);
    await appState.confirmCryType(_result!, actualType);

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Grazie! Il modello imparerà da questo feedback',
          ),
          backgroundColor: Colors.green,
        ),
      );
    }
  }
}
