#!/usr/bin/env python3
"""
Baby Cry Classifier Training Script
Addestra un modello CNN-LSTM per classificare il pianto dei neonati
"""

import os
import numpy as np
import tensorflow as tf
from tensorflow import keras
import librosa
from sklearn.model_selection import train_test_split
from sklearn.utils import class_weight
import matplotlib.pyplot as plt

# Configurazione
SAMPLE_RATE = 16000
DURATION = 7
N_MFCC = 13
N_MELS = 128
HOP_LENGTH = 512
N_FFT = 2048

CLASSES = ['hunger', 'sleepy', 'pain', 'diaper', 'gas', 'attention']

def extract_features(file_path, duration=DURATION):
    """
    Estrae Mel-spectrogram dall'audio
    
    Args:
        file_path: percorso file audio
        duration: durata in secondi
        
    Returns:
        Mel-spectrogram normalizzato
    """
    try:
        # Carica audio
        audio, sr = librosa.load(file_path, sr=SAMPLE_RATE, duration=duration)
        
        # Padding se troppo corto
        target_length = SAMPLE_RATE * duration
        if len(audio) < target_length:
            audio = np.pad(audio, (0, target_length - len(audio)))
        else:
            audio = audio[:target_length]
        
        # Mel-spectrogram
        mel_spec = librosa.feature.melspectrogram(
            y=audio,
            sr=sr,
            n_mels=N_MELS,
            n_fft=N_FFT,
            hop_length=HOP_LENGTH
        )
        
        # Converti in dB
        mel_spec_db = librosa.power_to_db(mel_spec, ref=np.max)
        
        # Normalizza
        mel_spec_norm = (mel_spec_db - mel_spec_db.mean()) / mel_spec_db.std()
        
        return mel_spec_norm
        
    except Exception as e:
        print(f"Errore nell'estrazione features da {file_path}: {e}")
        return None

def load_dataset(data_dir, subset='train'):
    """
    Carica il dataset e estrae le features
    
    Args:
        data_dir: directory del dataset
        subset: 'train', 'validation', o 'test'
        
    Returns:
        X: array di features
        y: array di label
    """
    print(f"\n📂 Caricamento dataset '{subset}'...")
    
    X = []
    y = []
    
    subset_dir = os.path.join(data_dir, subset)
    
    for idx, class_name in enumerate(CLASSES):
        class_dir = os.path.join(subset_dir, class_name)
        
        if not os.path.exists(class_dir):
            print(f"⚠️  Directory non trovata: {class_dir}")
            continue
        
        files = [f for f in os.listdir(class_dir) if f.endswith('.wav')]
        print(f"   {class_name}: {len(files)} file")
        
        for file_name in files:
            file_path = os.path.join(class_dir, file_name)
            
            features = extract_features(file_path)
            
            if features is not None:
                X.append(features)
                y.append(idx)
    
    print(f"✅ Caricati {len(X)} campioni da '{subset}'")
    
    return np.array(X), np.array(y)

def create_model(input_shape, num_classes):
    """
    Crea il modello CNN-LSTM
    
    Args:
        input_shape: forma dell'input (mel_bins, time_steps, channels)
        num_classes: numero di classi
        
    Returns:
        Modello Keras compilato
    """
    model = keras.Sequential([
        # Input
        keras.layers.Input(shape=input_shape),
        
        # Convolutional blocks
        keras.layers.Conv2D(32, (3, 3), activation='relu', padding='same'),
        keras.layers.BatchNormalization(),
        keras.layers.MaxPooling2D((2, 2)),
        keras.layers.Dropout(0.25),
        
        keras.layers.Conv2D(64, (3, 3), activation='relu', padding='same'),
        keras.layers.BatchNormalization(),
        keras.layers.MaxPooling2D((2, 2)),
        keras.layers.Dropout(0.25),
        
        keras.layers.Conv2D(128, (3, 3), activation='relu', padding='same'),
        keras.layers.BatchNormalization(),
        keras.layers.MaxPooling2D((2, 2)),
        keras.layers.Dropout(0.25),
        
        # Reshape per LSTM
        keras.layers.Reshape((-1, 128)),
        
        # LSTM per catturare pattern temporali
        keras.layers.LSTM(64, return_sequences=False),
        keras.layers.Dropout(0.5),
        
        # Dense layers
        keras.layers.Dense(128, activation='relu'),
        keras.layers.Dropout(0.5),
        keras.layers.Dense(num_classes, activation='softmax')
    ], name='BabyCryClassifier')
    
    return model

def plot_history(history, save_path='training_history.png'):
    """Visualizza l'andamento del training"""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4))
    
    # Accuracy
    ax1.plot(history.history['accuracy'], label='Train')
    ax1.plot(history.history['val_accuracy'], label='Validation')
    ax1.set_title('Model Accuracy')
    ax1.set_xlabel('Epoch')
    ax1.set_ylabel('Accuracy')
    ax1.legend()
    ax1.grid(True)
    
    # Loss
    ax2.plot(history.history['loss'], label='Train')
    ax2.plot(history.history['val_loss'], label='Validation')
    ax2.set_title('Model Loss')
    ax2.set_xlabel('Epoch')
    ax2.set_ylabel('Loss')
    ax2.legend()
    ax2.grid(True)
    
    plt.tight_layout()
    plt.savefig(save_path)
    print(f"📊 Grafici salvati in: {save_path}")

def train_model(data_dir='../dataset', model_dir='models', epochs=100, batch_size=32):
    """
    Pipeline completo di training
    
    Args:
        data_dir: directory del dataset
        model_dir: directory per salvare i modelli
        epochs: numero di epoche
        batch_size: dimensione batch
    """
    # Crea directory modelli
    os.makedirs(model_dir, exist_ok=True)
    
    # Carica dataset
    X_train, y_train = load_dataset(data_dir, 'train')
    X_val, y_val = load_dataset(data_dir, 'validation')
    
    if len(X_train) == 0:
        print("❌ Nessun dato di training trovato!")
        return
    
    # Reshape per CNN (aggiungi canale)
    X_train = X_train[..., np.newaxis]
    X_val = X_val[..., np.newaxis]
    
    # One-hot encoding
    y_train = keras.utils.to_categorical(y_train, num_classes=len(CLASSES))
    y_val = keras.utils.to_categorical(y_val, num_classes=len(CLASSES))
    
    print(f"\n📊 Dataset:")
    print(f"   Training: {X_train.shape}")
    print(f"   Validation: {X_val.shape}")
    
    # Class weights per gestire sbilanciamento
    class_weights = class_weight.compute_class_weight(
        'balanced',
        classes=np.unique(np.argmax(y_train, axis=1)),
        y=np.argmax(y_train, axis=1)
    )
    class_weights_dict = dict(enumerate(class_weights))
    
    # Crea modello
    print("\n🏗️  Creazione modello...")
    model = create_model(
        input_shape=X_train.shape[1:],
        num_classes=len(CLASSES)
    )
    
    # Compila
    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=0.001),
        loss='categorical_crossentropy',
        metrics=['accuracy']
    )
    
    model.summary()
    
    # Callbacks
    callbacks = [
        keras.callbacks.EarlyStopping(
            monitor='val_loss',
            patience=15,
            restore_best_weights=True,
            verbose=1
        ),
        keras.callbacks.ReduceLROnPlateau(
            monitor='val_loss',
            factor=0.5,
            patience=5,
            min_lr=1e-7,
            verbose=1
        ),
        keras.callbacks.ModelCheckpoint(
            os.path.join(model_dir, 'best_model.h5'),
            monitor='val_accuracy',
            save_best_only=True,
            verbose=1
        ),
        keras.callbacks.CSVLogger(
            os.path.join(model_dir, 'training_log.csv')
        )
    ]
    
    # Training
    print("\n🚀 Inizio training...")
    history = model.fit(
        X_train, y_train,
        validation_data=(X_val, y_val),
        epochs=epochs,
        batch_size=batch_size,
        callbacks=callbacks,
        class_weight=class_weights_dict,
        verbose=1
    )
    
    # Valutazione finale
    print("\n📊 Valutazione finale...")
    val_loss, val_acc = model.evaluate(X_val, y_val, verbose=0)
    print(f"   Validation Loss: {val_loss:.4f}")
    print(f"   Validation Accuracy: {val_acc:.2%}")
    
    # Plot
    plot_history(history, os.path.join(model_dir, 'training_history.png'))
    
    # Salva modello finale
    model_path = os.path.join(model_dir, 'final_model.h5')
    model.save(model_path)
    print(f"💾 Modello salvato: {model_path}")
    
    return model, history

def convert_to_tflite(model_path='models/best_model.h5', 
                       output_path='models/cry_classifier.tflite'):
    """
    Converte il modello Keras in TensorFlow Lite
    
    Args:
        model_path: percorso modello .h5
        output_path: percorso output .tflite
    """
    print("\n🔄 Conversione a TensorFlow Lite...")
    
    # Carica modello
    model = keras.models.load_model(model_path)
    
    # Converter
    converter = tf.lite.TFLiteConverter.from_keras_model(model)
    
    # Ottimizzazioni
    converter.optimizations = [tf.lite.Optimize.DEFAULT]
    
    # Quantizzazione (opzionale - riduce dimensione)
    # converter.target_spec.supported_types = [tf.float16]
    
    # Converti
    tflite_model = converter.convert()
    
    # Salva
    with open(output_path, 'wb') as f:
        f.write(tflite_model)
    
    size_mb = len(tflite_model) / (1024 * 1024)
    print(f"✅ Modello TFLite salvato: {output_path}")
    print(f"   Dimensione: {size_mb:.2f} MB")
    
    return output_path

def main():
    """Main function"""
    print("="*60)
    print("🍼 Baby Cry Classifier - Training Script")
    print("="*60)
    
    # Training
    model, history = train_model(
        data_dir='../dataset',
        model_dir='models',
        epochs=100,
        batch_size=32
    )
    
    # Conversione TFLite
    tflite_path = convert_to_tflite(
        model_path='models/best_model.h5',
        output_path='models/cry_classifier.tflite'
    )
    
    print("\n" + "="*60)
    print("🎉 Training completato!")
    print("="*60)
    print("\n📝 Prossimi passi:")
    print(f"1. Copia '{tflite_path}' in '../assets/models/'")
    print("2. Aggiorna pubspec.yaml per includere gli assets")
    print("3. Implementa l'analisi reale in ml_service.dart")
    print("\n✨ Buon lavoro!")

if __name__ == '__main__':
    main()
