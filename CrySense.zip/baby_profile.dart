class BabyProfile {
  final String id;
  final String name;
  final DateTime birthDate;
  final String? photoPath;
  final DateTime createdAt;

  BabyProfile({
    required this.id,
    required this.name,
    required this.birthDate,
    this.photoPath,
    required this.createdAt,
  });

  int get ageInMonths {
    final now = DateTime.now();
    return ((now.year - birthDate.year) * 12 + now.month - birthDate.month);
  }

  int get ageInDays {
    return DateTime.now().difference(birthDate).inDays;
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'birthDate': birthDate.toIso8601String(),
      'photoPath': photoPath,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  factory BabyProfile.fromMap(Map<String, dynamic> map) {
    return BabyProfile(
      id: map['id'],
      name: map['name'],
      birthDate: DateTime.parse(map['birthDate']),
      photoPath: map['photoPath'],
      createdAt: DateTime.parse(map['createdAt']),
    );
  }
}
