import 'dart:async';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:permission_handler/permission_handler.dart';

class AudioService {
  final AudioRecorder _recorder = AudioRecorder();
  bool _isRecording = false;
  String? _currentPath;
  Timer? _amplitudeTimer;
  final StreamController<double> _amplitudeController =
      StreamController<double>.broadcast();

  Stream<double> get amplitudeStream => _amplitudeController.stream;
  bool get isRecording => _isRecording;
  String? get currentPath => _currentPath;

  Future<bool> requestPermission() async {
    final status = await Permission.microphone.request();
    return status.isGranted;
  }

  Future<bool> checkPermission() async {
    final status = await Permission.microphone.status;
    return status.isGranted;
  }

  Future<String?> startRecording({int maxDuration = 10}) async {
    try {
      if (_isRecording) {
        await stopRecording();
      }

      final hasPermission = await checkPermission();
      if (!hasPermission) {
        final granted = await requestPermission();
        if (!granted) {
          return null;
        }
      }

      final directory = await getApplicationDocumentsDirectory();
      final timestamp = DateTime.now().millisecondsSinceEpoch;
      _currentPath = '${directory.path}/cry_$timestamp.m4a';

      await _recorder.start(
        const RecordConfig(
          encoder: AudioEncoder.aacLc,
          bitRate: 128000,
          sampleRate: 44100,
        ),
        path: _currentPath!,
      );

      _isRecording = true;

      // Monitor amplitude
      _amplitudeTimer = Timer.periodic(
        const Duration(milliseconds: 100),
        (timer) async {
          if (_isRecording) {
            final amplitude = await _recorder.getAmplitude();
            _amplitudeController.add(amplitude.current);
          }
        },
      );

      // Auto-stop after max duration
      Timer(Duration(seconds: maxDuration), () {
        if (_isRecording) {
          stopRecording();
        }
      });

      return _currentPath;
    } catch (e) {
      print('Error starting recording: $e');
      _isRecording = false;
      return null;
    }
  }

  Future<String?> stopRecording() async {
    try {
      if (!_isRecording) return null;

      _amplitudeTimer?.cancel();
      _amplitudeTimer = null;

      final path = await _recorder.stop();
      _isRecording = false;

      return path;
    } catch (e) {
      print('Error stopping recording: $e');
      _isRecording = false;
      return null;
    }
  }

  Future<void> cancelRecording() async {
    try {
      await stopRecording();
      if (_currentPath != null && File(_currentPath!).existsSync()) {
        await File(_currentPath!).delete();
      }
      _currentPath = null;
    } catch (e) {
      print('Error canceling recording: $e');
    }
  }

  Future<List<double>> getAudioFeatures(String filePath) async {
    // Placeholder: In un'implementazione reale, qui si estraggono le features audio
    // come MFCC, pitch, intensità, ecc. usando librerie come flutter_audio_capture
    // o processing in nativo
    
    // Per ora ritorniamo features simulate
    return List.generate(13, (index) => index * 0.1);
  }

  void dispose() {
    _amplitudeTimer?.cancel();
    _amplitudeController.close();
    _recorder.dispose();
  }
}
