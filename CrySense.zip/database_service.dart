import 'dart:convert';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/baby_profile.dart';
import '../models/cry_record.dart';
import '../models/cry_type.dart';

class DatabaseService {
  static final DatabaseService instance = DatabaseService._init();
  static Database? _database;

  DatabaseService._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('baby_cry.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(
      path,
      version: 1,
      onCreate: _createDB,
    );
  }

  Future _createDB(Database db, int version) async {
    const idType = 'TEXT PRIMARY KEY';
    const textType = 'TEXT NOT NULL';
    const realType = 'REAL NOT NULL';

    await db.execute('''
      CREATE TABLE baby_profiles (
        id $idType,
        name $textType,
        birthDate $textType,
        photoPath TEXT,
        createdAt $textType
      )
    ''');

    await db.execute('''
      CREATE TABLE cry_records (
        id $idType,
        babyId $textType,
        timestamp $textType,
        predictedType $textType,
        confidence $realType,
        confirmedType TEXT,
        audioPath TEXT,
        allProbabilities $textType,
        notes TEXT,
        FOREIGN KEY (babyId) REFERENCES baby_profiles (id)
      )
    ''');
  }

  // Baby Profile operations
  Future<BabyProfile> createBabyProfile(BabyProfile profile) async {
    final db = await instance.database;
    await db.insert('baby_profiles', profile.toMap());
    return profile;
  }

  Future<List<BabyProfile>> getAllBabyProfiles() async {
    final db = await instance.database;
    final result = await db.query('baby_profiles', orderBy: 'createdAt DESC');
    return result.map((json) => BabyProfile.fromMap(json)).toList();
  }

  Future<BabyProfile?> getBabyProfile(String id) async {
    final db = await instance.database;
    final maps = await db.query(
      'baby_profiles',
      where: 'id = ?',
      whereArgs: [id],
    );

    if (maps.isNotEmpty) {
      return BabyProfile.fromMap(maps.first);
    }
    return null;
  }

  // Cry Record operations
  Future<CryRecord> createCryRecord(CryRecord record) async {
    final db = await instance.database;
    final map = record.toMap();
    map['allProbabilities'] = jsonEncode(map['allProbabilities']);
    await db.insert('cry_records', map);
    return record;
  }

  Future<List<CryRecord>> getCryRecords(
    String babyId, {
    DateTime? startDate,
    DateTime? endDate,
    int? limit,
  }) async {
    final db = await instance.database;
    String where = 'babyId = ?';
    List<dynamic> whereArgs = [babyId];

    if (startDate != null) {
      where += ' AND timestamp >= ?';
      whereArgs.add(startDate.toIso8601String());
    }

    if (endDate != null) {
      where += ' AND timestamp <= ?';
      whereArgs.add(endDate.toIso8601String());
    }

    final result = await db.query(
      'cry_records',
      where: where,
      whereArgs: whereArgs,
      orderBy: 'timestamp DESC',
      limit: limit,
    );

    return result.map((map) {
      final parsedMap = Map<String, dynamic>.from(map);
      parsedMap['allProbabilities'] = jsonDecode(map['allProbabilities'] as String);
      return CryRecord.fromMap(parsedMap);
    }).toList();
  }

  Future<CryRecord> updateCryRecord(CryRecord record) async {
    final db = await instance.database;
    final map = record.toMap();
    map['allProbabilities'] = jsonEncode(map['allProbabilities']);
    
    await db.update(
      'cry_records',
      map,
      where: 'id = ?',
      whereArgs: [record.id],
    );
    return record;
  }

  Future<Map<CryType, int>> getCryStatistics(
    String babyId, {
    DateTime? startDate,
    DateTime? endDate,
  }) async {
    final records = await getCryRecords(
      babyId,
      startDate: startDate,
      endDate: endDate,
    );

    final stats = <CryType, int>{};
    for (var type in CryType.values) {
      stats[type] = 0;
    }

    for (var record in records) {
      stats[record.actualType] = (stats[record.actualType] ?? 0) + 1;
    }

    return stats;
  }

  Future<void> close() async {
    final db = await instance.database;
    db.close();
  }
}
