import 'package:flutter/material.dart';

enum CryType {
  hunger,
  sleepy,
  pain,
  diaper,
  gas,
  attention,
  unknown,
}

extension CryTypeExtension on CryType {
  String get displayName {
    switch (this) {
      case CryType.hunger:
        return 'Fame';
      case CryType.sleepy:
        return 'Sonno';
      case CryType.pain:
        return 'Dolore/Disagio';
      case CryType.diaper:
        return 'Pannolino';
      case CryType.gas:
        return 'Coliche/Gas';
      case CryType.attention:
        return 'Bisogno di Contatto';
      case CryType.unknown:
        return 'Non Identificato';
    }
  }

  String get emoji {
    switch (this) {
      case CryType.hunger:
        return '🍼';
      case CryType.sleepy:
        return '😴';
      case CryType.pain:
        return '😢';
      case CryType.diaper:
        return '💩';
      case CryType.gas:
        return '💨';
      case CryType.attention:
        return '🤗';
      case CryType.unknown:
        return '❓';
    }
  }

  Color get color {
    switch (this) {
      case CryType.hunger:
        return Colors.orange;
      case CryType.sleepy:
        return Colors.indigo;
      case CryType.pain:
        return Colors.red;
      case CryType.diaper:
        return Colors.brown;
      case CryType.gas:
        return Colors.green;
      case CryType.attention:
        return Colors.pink;
      case CryType.unknown:
        return Colors.grey;
    }
  }

  List<String> get suggestions {
    switch (this) {
      case CryType.hunger:
        return [
          'Prova ad allattare o dare il biberon',
          'Controlla quando è stata l\'ultima poppata',
          'Se rifiuta, potrebbe essere altro',
        ];
      case CryType.sleepy:
        return [
          'Crea un ambiente tranquillo e buio',
          'Cullalo dolcemente',
          'Prova la routine del sonno',
        ];
      case CryType.pain:
        return [
          'Controlla temperatura corporea',
          'Verifica se ci sono arrossamenti',
          'Se persiste, consulta il pediatra',
        ];
      case CryType.diaper:
        return [
          'Cambia il pannolino',
          'Controlla irritazioni cutanee',
          'Applica crema protettiva se necessario',
        ];
      case CryType.gas:
        return [
          'Massaggia delicatamente la pancia',
          'Prova la posizione anti-colica',
          'Fai fare il ruttino',
        ];
      case CryType.attention:
        return [
          'Prendi in braccio il bambino',
          'Parlagli con voce dolce',
          'Contatto pelle a pelle',
        ];
      case CryType.unknown:
        return [
          'Controlla i bisogni di base',
          'Verifica temperatura ambiente',
          'Osserva altri segnali',
        ];
    }
  }
}
