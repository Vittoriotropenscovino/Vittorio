import 'cry_type.dart';

class CryRecord {
  final String id;
  final String babyId;
  final DateTime timestamp;
  final CryType predictedType;
  final double confidence;
  final CryType? confirmedType;
  final String? audioPath;
  final Map<CryType, double> allProbabilities;
  final String? notes;

  CryRecord({
    required this.id,
    required this.babyId,
    required this.timestamp,
    required this.predictedType,
    required this.confidence,
    this.confirmedType,
    this.audioPath,
    required this.allProbabilities,
    this.notes,
  });

  CryType get actualType => confirmedType ?? predictedType;

  bool get wasConfirmed => confirmedType != null;

  bool get wasCorrect =>
      confirmedType == null || confirmedType == predictedType;

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'babyId': babyId,
      'timestamp': timestamp.toIso8601String(),
      'predictedType': predictedType.name,
      'confidence': confidence,
      'confirmedType': confirmedType?.name,
      'audioPath': audioPath,
      'allProbabilities': allProbabilities.map(
        (key, value) => MapEntry(key.name, value),
      ),
      'notes': notes,
    };
  }

  factory CryRecord.fromMap(Map<String, dynamic> map) {
    Map<CryType, double> probabilities = {};
    if (map['allProbabilities'] is String) {
      // Handle JSON string
      final probsMap = map['allProbabilities'] as Map<String, dynamic>;
      probsMap.forEach((key, value) {
        probabilities[CryType.values.firstWhere((e) => e.name == key)] =
            (value as num).toDouble();
      });
    } else {
      // Handle direct map
      (map['allProbabilities'] as Map).forEach((key, value) {
        probabilities[CryType.values.firstWhere((e) => e.name == key)] =
            (value as num).toDouble();
      });
    }

    return CryRecord(
      id: map['id'],
      babyId: map['babyId'],
      timestamp: DateTime.parse(map['timestamp']),
      predictedType:
          CryType.values.firstWhere((e) => e.name == map['predictedType']),
      confidence: (map['confidence'] as num).toDouble(),
      confirmedType: map['confirmedType'] != null
          ? CryType.values.firstWhere((e) => e.name == map['confirmedType'])
          : null,
      audioPath: map['audioPath'],
      allProbabilities: probabilities,
      notes: map['notes'],
    );
  }

  CryRecord copyWith({
    CryType? confirmedType,
    String? notes,
  }) {
    return CryRecord(
      id: id,
      babyId: babyId,
      timestamp: timestamp,
      predictedType: predictedType,
      confidence: confidence,
      confirmedType: confirmedType ?? this.confirmedType,
      audioPath: audioPath,
      allProbabilities: allProbabilities,
      notes: notes ?? this.notes,
    );
  }
}
