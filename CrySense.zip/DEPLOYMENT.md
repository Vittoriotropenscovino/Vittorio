# 🚀 Guida Build e Deployment

## Build per Testing Locale

### Android

```bash
# Debug build (per testing rapido)
flutter run

# Release build (APK)
flutter build apk --release

# Output: build/app/outputs/flutter-apk/app-release.apk
```

### iOS

```bash
# Debug su simulatore
flutter run -d "iPhone 14"

# Release build
flutter build ios --release

# Poi apri in Xcode per firmare e archiviare
open ios/Runner.xcworkspace
```

## Preparazione per Store

### Google Play Store

#### 1. Configura build.gradle

File: `android/app/build.gradle`

```gradle
android {
    defaultConfig {
        applicationId "com.tuodominio.baby_cry_app"
        minSdkVersion 21
        targetSdkVersion 33
        versionCode 1
        versionName "1.0.0"
    }

    signingConfigs {
        release {
            keyAlias keystoreProperties['keyAlias']
            keyPassword keystoreProperties['keyPassword']
            storeFile keystoreProperties['storeFile'] ? file(keystoreProperties['storeFile']) : null
            storePassword keystoreProperties['storePassword']
        }
    }

    buildTypes {
        release {
            signingConfig signingConfigs.release
            minifyEnabled true
            proguardFiles getDefaultProguardFile('proguard-android.txt'), 'proguard-rules.pro'
        }
    }
}
```

#### 2. Crea Keystore

```bash
keytool -genkey -v -keystore ~/upload-keystore.jks \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias upload
```

#### 3. Crea key.properties

File: `android/key.properties`

```properties
storePassword=<password>
keyPassword=<password>
keyAlias=upload
storeFile=<percorso-keystore.jks>
```

⚠️ **NON committare mai questo file su Git!**

#### 4. Build App Bundle

```bash
flutter build appbundle --release

# Output: build/app/outputs/bundle/release/app-release.aab
```

#### 5. Upload su Google Play Console

1. Vai su [Google Play Console](https://play.google.com/console)
2. Crea una nuova applicazione
3. Compila store listing
4. Upload app-release.aab
5. Imposta prezzi e distribuzione
6. Invia per review

### Apple App Store

#### 1. Configura Bundle ID

File: `ios/Runner.xcodeproj/project.pbxproj`

Apri in Xcode e imposta:
- Bundle Identifier: `com.tuodominio.babycryapp`
- Team: Seleziona il tuo team developer

#### 2. Configura Capabilities

In Xcode:
- Signing & Capabilities
- Abilita "Automatically manage signing"

#### 3. Build Archive

```bash
flutter build ios --release
```

In Xcode:
1. Product → Archive
2. Window → Organizer
3. Seleziona l'archivio
4. Distribute App → App Store Connect
5. Upload

#### 4. App Store Connect

1. Vai su [App Store Connect](https://appstoreconnect.apple.com)
2. Crea nuova app
3. Compila informazioni app
4. Upload screenshots
5. Seleziona build
6. Invia per review

## Asset Preparation

### Icon App

Crea icon nelle seguenti dimensioni:

**Android:**
- 48x48 (mdpi)
- 72x72 (hdpi)
- 96x96 (xhdpi)
- 144x144 (xxhdpi)
- 192x192 (xxxhdpi)

**iOS:**
- 20x20, 29x29, 40x40, 58x58, 60x60
- 80x80, 87x87, 120x120, 180x180
- 1024x1024 (App Store)

Usa `flutter_launcher_icons`:

```yaml
# pubspec.yaml
dev_dependencies:
  flutter_launcher_icons: ^0.13.1

flutter_launcher_icons:
  android: true
  ios: true
  image_path: "assets/icon/app_icon.png"
```

```bash
flutter pub run flutter_launcher_icons
```

### Screenshot Store

Dimensioni richieste:

**Android:**
- Phone: 1080x1920 o 1080x2340
- Tablet 7": 1200x1920
- Tablet 10": 1536x2048

**iOS:**
- iPhone 6.7": 1290x2796
- iPhone 6.5": 1284x2778
- iPhone 5.5": 1242x2208
- iPad Pro 12.9": 2048x2732

### Video Preview (opzionale)

- Lunghezza: 15-30 secondi
- Risoluzione: 1080p
- Mostra features principali

## Store Listing

### Descrizione App (Italiano)

**Titolo:** Baby Cry Analyzer - AI per Neo Genitori

**Descrizione Breve:**
Scopri cosa vuole il tuo bambino! Analisi AI del pianto in tempo reale.

**Descrizione Completa:**

```
👶 Baby Cry Analyzer - Il Tuo Assistente Intelligente

Sei un neo genitore e non sai sempre interpretare il pianto del tuo bambino? 
Baby Cry Analyzer usa l'intelligenza artificiale per aiutarti a capire i 
bisogni del tuo piccolo in pochi secondi!

✨ CARATTERISTICHE PRINCIPALI:

🎯 Riconoscimento AI Accurato
• Identifica 6 tipi di pianto: fame, sonno, dolore, pannolino, coliche, contatto
• Risultati in meno di 2 secondi
• Si adatta al pianto specifico del tuo bambino

📊 Statistiche Dettagliate
• Monitora i pattern nel tempo
• Identifica routine e abitudini
• Grafici intuitivi

🔒 Privacy Garantita al 100%
• Tutti i dati restano sul tuo dispositivo
• Nessun caricamento nel cloud
• Funziona completamente offline

💡 Suggerimenti Pratici
• Consigli specifici per ogni tipo di pianto
• Impara a riconoscere i segnali
• Diventa un genitore più sicuro

🎨 Interfaccia Intuitiva
• Design pensato per essere usato anche di notte
• Modalità notturna con bassa luminosità
• Funzionamento con un solo tocco

⚠️ IMPORTANTE:
Questa app è uno strumento di supporto e non sostituisce il consiglio medico. 
Consulta sempre il pediatra per dubbi sulla salute del bambino.

📱 Requisiti:
• Android 8.0+ / iOS 13+
• Permesso microfono

🆓 COMPLETAMENTE GRATUITO
• Nessun abbonamento
• Nessun acquisto in-app
• Nessuna pubblicità

Scarica ora e inizia a comprendere meglio il tuo bambino! 👶💙
```

### Keywords (per ASO - App Store Optimization)

```
pianto neonato, baby cry, neonato, genitori, bambini, intelligenza artificiale,
AI, analisi pianto, neo genitori, app genitori, baby monitor, baby care,
riconoscimento pianto, pediatria, allattamento, sonno neonato
```

### Categorie

- **Primaria**: Salute e Benessere / Famiglia
- **Secondaria**: Strumenti / Educazione

## Privacy Policy

⚠️ **OBBLIGATORIO** per gli store!

Esempio minimo (da personalizzare):

```markdown
# Privacy Policy per Baby Cry Analyzer

Ultimo aggiornamento: [Data]

## Raccolta Dati

La nostra app NON raccoglie, trasmette o condivide alcun dato personale.

## Dati Locali

- Tutti i dati rimangono sul dispositivo dell'utente
- Le registrazioni audio vengono eliminate dopo l'analisi
- Lo storico dei pianti è salvato solo localmente

## Permessi

L'app richiede accesso al microfono esclusivamente per:
- Registrare il pianto del bambino durante l'analisi
- I file audio non vengono mai trasmessi online

## Contatti

Per domande: [tua email]
```

Pubblica su: `https://tuosito.com/privacy-policy`

## Termini di Servizio

Pubblica anche i Termini di Servizio:
`https://tuosito.com/terms-of-service`

## Compliance

### GDPR (Europa)

✅ Rispettato automaticamente perché:
- Nessun dato personale raccolto
- Nessun tracking
- Tutto locale

### COPPA (USA - Children's Online Privacy Protection Act)

✅ L'app non raccoglie dati da minori

### Disclaimer Medico

⚠️ Includi sempre:
```
"Questa applicazione non è un dispositivo medico e non fornisce 
diagnosi mediche. Consultare sempre un professionista sanitario 
qualificato per questioni relative alla salute."
```

## Analytics (Opzionale)

Se vuoi aggiungere analytics rispettando la privacy:

### Firebase Analytics

```yaml
# pubspec.yaml
dependencies:
  firebase_core: ^2.24.0
  firebase_analytics: ^10.7.4
```

Configura solo eventi anonimi:
- Numero di analisi eseguite
- Tipo di pianto più comune (aggregato)
- MAI informazioni personali

## Testing Pre-Release

### Beta Testing

**Android:**
1. Play Console → Testing → Closed testing
2. Crea lista email tester
3. Upload APK/AAB beta
4. Invia invito ai tester

**iOS:**
1. TestFlight
2. Upload build
3. Aggiungi tester (max 10,000)
4. Raccogli feedback

### Checklist Pre-Launch

- [ ] Test su almeno 5 device diversi
- [ ] Test permessi microfono
- [ ] Test offline
- [ ] Verifica traduzioni
- [ ] Test crash con Firebase Crashlytics
- [ ] Performance testing (battery, memory)
- [ ] Accessibilità (screen reader)
- [ ] Privacy policy pubblicata
- [ ] Screenshots di qualità
- [ ] Video demo pronto
- [ ] Description store complete
- [ ] Keywords ottimizzate

## Post-Launch

### Monitoring

1. **Crash Reports**: Firebase Crashlytics
2. **Performance**: Firebase Performance Monitoring
3. **User Feedback**: Rispondi alle recensioni
4. **Updates**: Fix bug + nuove features

### Marketing

1. Product Hunt launch
2. Reddit (r/parenting, r/NewParents)
3. Facebook groups per genitori
4. Instagram/TikTok demo video
5. Blog post su siti parenting

## Versioning

Segui Semantic Versioning:

```
MAJOR.MINOR.PATCH

1.0.0 - Release iniziale
1.0.1 - Bug fix
1.1.0 - Nuova feature minore
2.0.0 - Breaking changes
```

Aggiorna in `pubspec.yaml`:
```yaml
version: 1.0.0+1
```

## Support

Prepara:
1. Email di supporto
2. FAQ page
3. Video tutorial
4. Canale feedback (form/email)

---

Buona fortuna con il lancio! 🚀
