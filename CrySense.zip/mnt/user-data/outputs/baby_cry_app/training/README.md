# 🧠 Training del Modello ML

Questa cartella contiene gli script per addestrare il modello di classificazione del pianto.

## 📋 Setup Ambiente

### 1. Crea Virtual Environment

```bash
python -m venv venv
source venv/bin/activate  # Linux/Mac
# oppure
venv\Scripts\activate     # Windows
```

### 2. Installa Dipendenze

```bash
pip install -r requirements.txt
```

## 📊 Prepara Dataset

Struttura richiesta:

```
dataset/
├── train/
│   ├── hunger/
│   │   ├── cry_001.wav
│   │   ├── cry_002.wav
│   │   └── ...
│   ├── sleepy/
│   ├── pain/
│   ├── diaper/
│   ├── gas/
│   └── attention/
├── validation/
│   └── [stessa struttura]
└── test/
    └── [stessa struttura]
```

### Requisiti Audio

- **Formato**: WAV (raccomandato) o MP3
- **Sample Rate**: 16kHz o superiore (verrà resampliato)
- **Durata**: ~7 secondi (o verrà tagliato/paddato)
- **Canali**: Mono preferito

## 🚀 Esegui Training

```bash
python train_model.py
```

Il script:
1. ✅ Carica il dataset
2. ✅ Estrae features (Mel-spectrogram)
3. ✅ Addestra il modello CNN-LSTM
4. ✅ Salva il best model
5. ✅ Converte in TensorFlow Lite
6. ✅ Genera grafici di training

## 📁 Output

Dopo il training troverai:

```
models/
├── best_model.h5              # Modello Keras (best validation)
├── final_model.h5             # Modello finale
├── cry_classifier.tflite      # ⭐ Modello per Flutter
├── training_log.csv           # Log metriche
└── training_history.png       # Grafici accuracy/loss
```

## 🔧 Configurazione

Modifica i parametri in `train_model.py`:

```python
# Audio
SAMPLE_RATE = 16000    # Hz
DURATION = 7           # secondi
N_MELS = 128          # Mel bins

# Training
epochs = 100
batch_size = 32
learning_rate = 0.001
```

## 📊 Valutazione

### Durante Training

Il modello usa:
- **Early Stopping**: Si ferma se non migliora per 15 epoche
- **Learning Rate Reduction**: Riduce LR se plateau
- **Class Weighting**: Gestisce sbilanciamento classi

### Metriche Target

- **Accuracy**: >85% su validation
- **Overfitting**: Gap train-val <10%
- **Dimensione**: <10MB (TFLite)

## 🎯 Migliorie Possibili

### Data Augmentation

Aggiungi in `extract_features()`:

```python
# Pitch shift
audio_pitched = librosa.effects.pitch_shift(audio, sr, n_steps=2)

# Time stretch
audio_stretched = librosa.effects.time_stretch(audio, rate=1.1)

# Add noise
noise = np.random.randn(len(audio))
audio_noisy = audio + 0.005 * noise
```

### Transfer Learning

Usa modelli pre-trained:

```python
from tensorflow.keras.applications import VGG16

base_model = VGG16(
    include_top=False,
    weights='imagenet',
    input_shape=(128, 128, 3)
)
base_model.trainable = False  # Freeze
```

### Ensemble

Combina più modelli:

```python
predictions = []
for model in models:
    pred = model.predict(X)
    predictions.append(pred)

final_pred = np.mean(predictions, axis=0)
```

## 🐛 Troubleshooting

### "No module named 'librosa'"

```bash
pip install librosa
```

### "Out of Memory"

Riduci `batch_size`:

```python
batch_size = 16  # o 8
```

### "Audio files not found"

Verifica percorsi:
```bash
ls -la ../dataset/train/hunger/
```

### Accuratezza bassa (<70%)

1. Aumenta dataset (>1000 per classe)
2. Bilancia le classi
3. Aggiungi data augmentation
4. Aumenta epoche
5. Prova architetture diverse

## 📚 Risorse

- [Librosa Tutorial](https://librosa.org/doc/latest/tutorial.html)
- [TensorFlow Audio](https://www.tensorflow.org/tutorials/audio/simple_audio)
- [Audio Deep Learning](https://arxiv.org/abs/1609.04243)

## 💡 Tips

1. **Inizia piccolo**: 500 campioni per testare pipeline
2. **Monitor overfitting**: Usa validation set
3. **Save checkpoints**: Non perdere progresso
4. **Log metriche**: Traccia esperimenti
5. **Test su device**: Inferenza su smartphone

## 🎓 Papers di Riferimento

1. "Automatic Cry Analysis" - Reyes-Galaviz et al.
2. "Baby Cry Recognition Using Deep Learning" - Rosales-Pérez et al.
3. "Acoustic Analysis of Infant Cry" - Manfredi et al.

---

Buon training! 🚀
