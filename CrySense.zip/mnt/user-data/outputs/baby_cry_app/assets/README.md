# Assets Directory

Questa directory contiene gli asset statici dell'applicazione.

## 📁 Struttura

```
assets/
├── models/
│   └── cry_classifier.tflite    # Modello ML (da aggiungere)
└── icons/
    └── app_icon.png             # Icon dell'app (da aggiungere)
```

## 🧠 Modelli ML

### cry_classifier.tflite

Questo è il modello TensorFlow Lite per la classificazione del pianto.

**Come ottenerlo:**

1. Addestra il modello usando `training/train_model.py`
2. Il file `.tflite` verrà generato in `training/models/`
3. Copialo qui: `cp ../training/models/cry_classifier.tflite models/`

**Dimensione attesa:** ~5-10 MB

**Se non hai ancora il modello:**
L'app funziona comunque con il classificatore simulato in `ml_service.dart`

## 🎨 Icone

### app_icon.png

L'icona dell'applicazione.

**Requisiti:**
- Formato: PNG
- Dimensione: 1024x1024 px
- Sfondo: Trasparente o colorato
- Contenuto: Logo/icona rappresentativa

**Generazione automatica:**

```bash
# Dopo aver aggiunto app_icon.png qui
flutter pub run flutter_launcher_icons
```

Questo genererà automaticamente tutte le dimensioni per Android e iOS.

## 📝 Note

- Tutti i file in questa directory devono essere dichiarati in `pubspec.yaml`
- Gli asset aumentano la dimensione dell'app, usali con parsimonia
- Comprimi le immagini prima di aggiungerle (usa TinyPNG o simili)

## 🔧 Aggiungi Asset in pubspec.yaml

```yaml
flutter:
  assets:
    - assets/models/cry_classifier.tflite
    - assets/icons/
```
