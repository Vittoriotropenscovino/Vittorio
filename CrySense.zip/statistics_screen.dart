import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart';
import '../providers/app_state.dart';
import '../models/cry_type.dart';
import 'package:intl/intl.dart';

class StatisticsScreen extends StatefulWidget {
  const StatisticsScreen({super.key});

  @override
  State<StatisticsScreen> createState() => _StatisticsScreenState();
}

class _StatisticsScreenState extends State<StatisticsScreen> {
  String _selectedPeriod = 'today';
  Map<CryType, int> _stats = {};

  @override
  void initState() {
    super.initState();
    _loadStats();
  }

  Future<void> _loadStats() async {
    final appState = Provider.of<AppState>(context, listen: false);
    DateTime startDate;
    DateTime endDate = DateTime.now();

    switch (_selectedPeriod) {
      case 'today':
        startDate = DateTime(endDate.year, endDate.month, endDate.day);
        break;
      case 'week':
        startDate = endDate.subtract(const Duration(days: 7));
        break;
      case 'month':
        startDate = DateTime(endDate.year, endDate.month - 1, endDate.day);
        break;
      default:
        startDate = DateTime(endDate.year, endDate.month, endDate.day);
    }

    final stats = await appState.getStatsForPeriod(
      startDate: startDate,
      endDate: endDate,
    );

    setState(() {
      _stats = stats;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Statistiche'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Period selector
            _buildPeriodSelector(),
            const SizedBox(height: 24),

            // Pie chart
            _buildPieChart(),
            const SizedBox(height: 32),

            // Stats list
            _buildStatsList(),
            const SizedBox(height: 32),

            // Insights
            _buildInsights(),
          ],
        ),
      ),
    );
  }

  Widget _buildPeriodSelector() {
    return Row(
      children: [
        Expanded(
          child: _buildPeriodButton('Oggi', 'today'),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: _buildPeriodButton('7 Giorni', 'week'),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: _buildPeriodButton('30 Giorni', 'month'),
        ),
      ],
    );
  }

  Widget _buildPeriodButton(String label, String period) {
    final isSelected = _selectedPeriod == period;
    return ElevatedButton(
      onPressed: () {
        setState(() {
          _selectedPeriod = period;
        });
        _loadStats();
      },
      style: ElevatedButton.styleFrom(
        backgroundColor: isSelected ? Colors.blue : Colors.grey[200],
        foregroundColor: isSelected ? Colors.white : Colors.black87,
        elevation: isSelected ? 2 : 0,
        padding: const EdgeInsets.symmetric(vertical: 12),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
      child: Text(label),
    );
  }

  Widget _buildPieChart() {
    final totalCries = _stats.values.fold(0, (sum, count) => sum + count);

    if (totalCries == 0) {
      return Container(
        height: 250,
        decoration: BoxDecoration(
          color: Colors.grey[100],
          borderRadius: BorderRadius.circular(16),
        ),
        child: const Center(
          child: Text(
            'Nessun dato disponibile',
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey,
            ),
          ),
        ),
      );
    }

    final sections = _stats.entries
        .where((entry) => entry.value > 0)
        .map((entry) {
      final percentage = (entry.value / totalCries * 100);
      return PieChartSectionData(
        value: entry.value.toDouble(),
        title: '${percentage.toStringAsFixed(0)}%',
        color: entry.key.color,
        radius: 100,
        titleStyle: const TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.bold,
          color: Colors.white,
        ),
      );
    }).toList();

    return Column(
      children: [
        SizedBox(
          height: 250,
          child: PieChart(
            PieChartData(
              sections: sections,
              sectionsSpace: 2,
              centerSpaceRadius: 40,
            ),
          ),
        ),
        const SizedBox(height: 16),
        Text(
          'Totale pianti: $totalCries',
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  Widget _buildStatsList() {
    final sortedStats = _stats.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    final filteredStats = sortedStats.where((entry) => entry.value > 0).toList();

    if (filteredStats.isEmpty) {
      return const SizedBox.shrink();
    }

    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Dettaglio',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            ...filteredStats.map((entry) => Padding(
                  padding: const EdgeInsets.only(bottom: 16),
                  child: Row(
                    children: [
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: entry.key.color.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Center(
                          child: Text(
                            entry.key.emoji,
                            style: const TextStyle(fontSize: 20),
                          ),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              entry.key.displayName,
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            Text(
                              'Ultimo: ${_getLastTime(entry.key)}',
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.grey[600],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 8,
                        ),
                        decoration: BoxDecoration(
                          color: entry.key.color,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          '${entry.value}',
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),
                      ),
                    ],
                  ),
                )),
          ],
        ),
      ),
    );
  }

  String _getLastTime(CryType type) {
    final appState = Provider.of<AppState>(context, listen: false);
    return appState.getTimeSinceLastCry(type);
  }

  Widget _buildInsights() {
    final sortedStats = _stats.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    
    final filteredStats = sortedStats.where((e) => e.value > 0).toList();
    
    if (filteredStats.isEmpty) {
      return const SizedBox.shrink();
    }

    final mostCommon = filteredStats.first;
    final totalCries = _stats.values.fold(0, (sum, count) => sum + count);

    return Card(
      elevation: 2,
      color: Colors.blue[50],
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.insights, color: Colors.blue),
                SizedBox(width: 8),
                Text(
                  'Insights',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Text(
              '• Il motivo più frequente è ${mostCommon.key.displayName} '
              '(${mostCommon.value} volte, ${(mostCommon.value / totalCries * 100).toStringAsFixed(0)}%)',
              style: const TextStyle(fontSize: 15),
            ),
            const SizedBox(height: 12),
            Text(
              '• Media giornaliera: ${_getDailyAverage(totalCries)} pianti',
              style: const TextStyle(fontSize: 15),
            ),
            if (_selectedPeriod != 'today' && filteredStats.length > 1) ...[
              const SizedBox(height: 12),
              Text(
                '• Secondo motivo più comune: ${filteredStats[1].key.displayName}',
                style: const TextStyle(fontSize: 15),
              ),
            ],
          ],
        ),
      ),
    );
  }

  String _getDailyAverage(int total) {
    final days = _selectedPeriod == 'today'
        ? 1
        : _selectedPeriod == 'week'
            ? 7
            : 30;
    return (total / days).toStringAsFixed(1);
  }
}
